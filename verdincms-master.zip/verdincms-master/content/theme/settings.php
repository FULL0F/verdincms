<section class="section-stats">
<div class="container-sm">
 	<div class="page">
 		<h1>Ρυθμίσεις</h1>

		<h2>Σειρά Σελίδων</h2>
		<ul class="sort-pages" data-action="<?=site_url('site/ajax_positions')?>">
			<?php foreach ($pages as $item):?>
				<li class="" data-id="<?=$item['id']?>" data-position="<?=$item['position']?>"><?=$item['title']?></li>
			<?php endforeach;?>			
		</ul>

		<h2><a href="#basic_set" class="toggle-collapse">Βασικές Ρυθμίσεις</a></h2>
		<div class="basic-settings collapse" id="basic_set">
			<form action="" method="post">
				<h5>Βασικά</h5>

				<?php foreach ($settings as $item):?>
				<div class="input-group">
					<input type="text" class="form-control" placeholder="<?=$item['title']?>" name="<?=$item['setting']?>" value="<?=set_value($item['setting'])?>">
					<label><?=$item['title']?></label>						
				</div>					
				<?php endforeach;?>
				
				<div class="text-right">
					<button class="btn btn-primary" type="submit" name="submitSettings" Value="Submit Settings">Αποθήκευση</button>
				</div>
			</form>
		</div>

		<?php if(!empty($deleted_posts)):?>
		<h2>Διεγραμμένα Άρθρα</h2>
		<ul class="stats">
			<?php foreach ($deleted_posts as $item):?>
				<li class="single-line"><a href="<?=site_url('post/'.$item['id'])?>"><?=$item['title']?></a></li>
			<?php endforeach;?>
		</ul>
		<form action="" method="post" class="stats-button"> 					
			<button class="btn btn-danger" type="submit" name="delRecycledPosts" Value="Delete Recycled Posts">Διαγραφή Ανακυκλωμένων Άρθρων</button>
		</form>
		<?php endif;?>

		<?php if(!empty($deleted_pages)):?>
		<h2>Διεγραμμένες Σελίδες</h2>
		<ul class="stats">
			<?php foreach ($deleted_pages as $item):?>
				<li class="single-line"><a href="<?=site_url($item['slug'])?>"><?=$item['title']?></a></li>
			<?php endforeach;?>
		</ul>
		<form action="" method="post" class="stats-button"> 					
			<button class="btn btn-danger" type="submit" name="delRecycledPages" Value="Delete Recycled Pages">Διαγραφή Ανακυκλωμένων Σελίδων</button>
		</form>
		<?php endif;?>		
		
		<?php if(!empty($photos)):?>		
		<h2>Αχρησιμοποίητες Φωτογραφίες</h2>
		<div class="stats">
			<?php foreach ($photos as $item):?>
				<a href="<?=upload_images().$item?>" class="thumb lazy" target="_blank" data-src="<?=upload_images().$item?>">&nbsp;</a>
			<?php endforeach;?>			
		</div>
		<form action="" method="post" class="stats-button"> 					
			<button class="btn btn-danger" type="submit" name="delPhotos" Value="Delete Photos">Διαγραφή Αχρησιμοποίητων Φωτογραφιών</button>
		</form>
		<?php endif;?>	

		<h2><a href="#db_backups" class="toggle-collapse">Αντίγραφα Βάσης</a></h2>
		<div class="collapse" id="db_backups">
			<ul class="stats">
				<?php foreach ($files as $item):?>
					<li class="single-line"><a href="<?=base_url().'content/backups/'.$item?>"><?=$item?></a></li>
				<?php endforeach;?>
			</ul>
			<form action="" method="post" class="stats-button">  
				<button class="btn btn-success" type="submit" name="backUpDb" Value="Backup Database">Νέο Αντίγραφο Βάσης</button>
			</form>
		</div>

		<h2><a href="#phpinfo" class="toggle-collapse">Πληροφορίες PHPinfo</a></h2>
		<ul class="stats collapse" id="phpinfo">
			<?php foreach ($php_info as $key => $value): ?>
			<li>
				<?=$key?> &rarr; <strong><?=$value?></strong>
			</li>
			<?php endforeach;?>
		</ul>
 	</div>			
</div>	
</section>