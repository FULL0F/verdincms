<nav class="navbar">
	<div class="nav-block nav-max">
		<div class="nav-items">
			<button class="side-toggle"><i class="fm icon-bars fm-lg"></i></button>
			<a href="<?=base_url()?>" class="hide-sm">Κεντρική</a>
			<?php if(isLoggedIn()):?>
				<a href="<?=site_url('list/posts')?>" class="hide-sm">Λίστα</a>
			<?php endif;?>
		</div>
	</div>
	<div class="nav-block nav-title"><a href="<?=base_url()?>"><img src="<?=theme_images().'svg/logo.svg'?>"></a></div>
	<div class="nav-block nav-max">
		<div class="nav-items right">	
			<?php if(!isLoggedIn()):?>	
			<a href="#" class="toggle-login"><i class="fm icon-unlock fm-lg hide-lg"></i> <span class="hide-sm">Είσοδος</span></a>
			<div class="drop-login">
				<h2>Είσοδος μέλους</h2>
		        <?php
		        if(!empty($success_msg)){
		            echo '<p class="statusMsg">'.$success_msg.'</p>';
		        }elseif(!empty($error_msg)){
		            echo '<p class="statusMsg">'.$error_msg.'</p>';
		        }
		        ?>
		        <form action="<?=site_url('users/login')?>" method="post">
		            <div class="form-group has-feedback">
		                <input type="email" class="form-control" name="email" placeholder="Email" required="" value="">
		                <?php echo form_error('email','<span class="help-block">','</span>'); ?>
		            </div>
		            <div class="form-group">
		              <input type="password" class="form-control" name="password" placeholder="Password" required="">
		              <?php echo form_error('password','<span class="help-block">','</span>'); ?>
		            </div>
		            <div class="form-group text-right">
		                <input type="submit" name="loginSubmit" class="btn btn-danger" value="Είσοδος"/>
		            </div>
		        </form>
			</div><!-- drop-login -->
			<?php else:?>
				<span class="nav-text nav-greeting hide-sm"><em>γειά Tom!</em></span>
			<?php endif;?>

			<?php if(isLoggedIn()):?>
				<a href="<?=site_url('edit_post/new')?>" class="hide-sm">Νέο Άρθρο</a>
				<?php if(!empty($id)):?>
					<a href="<?=site_url('edit_post/'.$id)?>" class="hide-sm">Επεξεργασία</a>
				<?php endif; ?>

				<?php if(!empty($page_id)):?>
					<a href="<?=site_url('edit_page/'.$page_id)?>" class="hide-sm">Επεξεργασία</a>
				<?php endif; ?>

				<a href="<?=site_url('users/logout')?>"><i class="fm icon-lock fm-lg hide-lg"></i><span class="hide-sm"> Έξοδος</span></a>
			<?php endif; ?>
			
		</div>		
	</div>
</nav>

<div class="nav-sidebar">
	<div class="nav-sidebar-items">
		<?php foreach ($pages as $page):?>
			<a href="<?=site_url($page['slug'])?>"><?=$page['title']?></a>			
		<?php endforeach;?>

		<?php if(isLoggedIn()):?>
			<span class="nav-sidebar-title">Διαχείριση</span>
			<?php if(!empty($id)):?>
				<a href="<?=site_url('edit_post/'.$id)?>">Επεξεργασία</a>
			<?php endif; ?>

			<?php if(!empty($page_id)):?>
				<a href="<?=site_url('edit_page/'.$page_id)?>">Επεξεργασία</a>
			<?php endif; ?>

			<a href="<?=site_url('edit_post/new')?>">Νέο Άρθρο</a>
			<a href="<?=site_url('edit_page/new')?>">Νέα Σελίδα</a>
			<a href="<?=site_url('list/posts')?>">Λίστα</a>
			<a href="<?=site_url('settings')?>">Ρυθμίσεις</a>
			<a href="<?=site_url('stats')?>">Στατιστικά</a>
		<?php endif;?>

	</div>
</div>
<div class="overlay"></div>