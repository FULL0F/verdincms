<!-- Datetime Picker -->
<div class="date-switch">
	<div class="datepicker">
		<div>
			<button class="up b-datepicker" data-action="sec-plus" type="button">δευτ</button>
			<button class="up b-datepicker" data-action="min-plus" type="button">λεπτά</button>
			<button class="up b-datepicker" data-action="hour-plus" type="button">ώρα</button>
			<button class="up b-datepicker" data-action="day-plus" type="button">μέρα</button>
			<button class="up b-datepicker" data-action="month-plus" type="button">μήνα</button>
			<button class="up b-datepicker" data-action="year-plus" type="button">έτος</button>
		</div>
		<div class="display">
			<div class="date-display">&nbsp;</div>
			<button class="b-datepicker bullseye" data-action="set-now" type="button"><i class="far fa-dot-circle fa-lg"></i></button>
		</div>
		<div>
			<button class="down b-datepicker" data-action="sec-minus" type="button">δευτ</button>
			<button class="down b-datepicker" data-action="min-minus" type="button">λεπτά</button>
			<button class="down b-datepicker" data-action="hour-minus" type="button">ώρα</button>
			<button class="down b-datepicker" data-action="day-minus" type="button">μέρα</button>
			<button class="down b-datepicker" data-action="month-minus" type="button">μήνα</button>
			<button class="down b-datepicker" data-action="year-minus" type="button">έτος</button>
		</div>			
	</div>
</div>
<!-- Datetime Picker -->