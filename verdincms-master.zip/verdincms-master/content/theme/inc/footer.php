<section class="section-footer">
	
	<footer class="container">
		<div class="footer-icons noselect">
			<?php if(!empty($this->config->item('cfg_facebook'))):?>
				<a href="<?=$this->config->item('cfg_facebook')?>" target="_blank"><i class="fm icon-facebook"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_twitter'))):?>
				<a href="<?=$this->config->item('cfg_twitter')?>" target="_blank"><i class="fm icon-twitter"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_instagram'))):?>
				<a href="<?=$this->config->item('cfg_instagram')?>" target="_blank"><i class="fm icon-instagram"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_youtube'))):?>
				<a href="<?=$this->config->item('cfg_youtube')?>" target="_blank"><i class="fm icon-youtube"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_github'))):?>
				<a href="<?=$this->config->item('cfg_github')?>" target="_blank"><i class="fm icon-github"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_patreon'))):?>
				<a href="<?=$this->config->item('cfg_patreon')?>" target="_blank"><i class="fm icon-patreon"></i></a>
			<?php endif;?>
			
			<?php if(!empty($this->config->item('cfg_jsfiddle'))):?>
				<a href="<?=$this->config->item('cfg_jsfiddle')?>" target="_blank"><i class="fm icon-jsfiddle"></i></a>
			<?php endif;?>

			<?php if(!empty($this->config->item('cfg_codepen'))):?>
				<a href="<?=$this->config->item('cfg_codepen')?>" target="_blank"><i class="fm icon-codepen"></i></a>
			<?php endif;?>			

			<?php if(!empty($this->config->item('cfg_contact_page'))):?>
				<a href="<?=$this->config->item('cfg_contact_page')?>"><i class="fm icon-email"></i></a>
			<?php endif;?>
			
			<a href="<?=site_url('feed')?>" target="_blank"><i class="fm icon-rss"></i></a>
		</div>

		<div class="footer-menu">
			<?php for ($i = 1; $i <= 1; $i++):?>
			<?php foreach ($pages as $page):?>
				<a href="<?=site_url($page['slug'])?>"><?=$page['title']?></a>			
			<?php endforeach;?>
			<?php endfor;?>
		</div>

		<div class="footer-copyright">
			<?=$this->config->item('cfg_copy_line_1')?><br><?=$this->config->item('cfg_copy_line_2')?> Rendered in: {elapsed_time} sec
		</div>
		<a href="#" class="back-to-top"><i class="fm icon-arrow-up fm-lg"></i></a>
	</footer>

</section>