<?=script_tag(theme_assets().'jquery/engine.min.js')?>
<?=script_tag(theme_url().'js/verdin.min.js?v301')?>
<?=(!empty($scripts)?$scripts:'')?>
</body>
</html>