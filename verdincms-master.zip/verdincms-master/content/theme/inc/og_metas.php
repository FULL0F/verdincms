<!-- Twitter Card data -->
<meta name="twitter:card" content="summary">
<meta name="twitter:site" content="<?=$this->config->item('cfg_twitter_alias')?>">
<meta name="twitter:title" content="<?=htmlspecialchars($title)?>">
<meta name="twitter:description" content="<?=htmlspecialchars($subtitle)?>">
<meta name="twitter:creator" content="<?=$this->config->item('cfg_twitter_alias')?>">
<meta name="twitter:image" content="<?=upload_images().$photo?>">

<!-- Open Graph data -->
<meta property="og:title" content="<?=htmlspecialchars($title)?>" />
<meta property="og:type" content="article" />
<meta property="og:url" content="<?=site_url('post/').$id?>" />
<meta property="og:image" content="<?=upload_images().$photo?>" />
<meta property="og:description" content="<?=htmlspecialchars($subtitle)?>" /> 
<meta property="og:site_name" content="<?=$this->config->item('cfg_site_name')?>" />
<meta property="fb:app_id" content="<?=$this->config->item('cfg_fb_app_id')?>" />
