<section class="section-soon">	
	<div class="container">
		<img class="svg-icon-title" src="<?=theme_images().'svg/soon.svg'?>">
	</div>
	<div class="container">		
		<?php foreach ($soon_posts as $item):?>
			<div class="soon-post">
				<div><h4><?=$item['title']?></h4></div>
				<div><?=$item['subtitle']?></div>				
			</div>
		<?php endforeach;?>		
	</div>
</section>