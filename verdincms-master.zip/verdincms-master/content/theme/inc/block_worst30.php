<section class="section-posts top30">
	<div class="container"><h2 class="text-center">Είναι αυτό που δεν εννοούμε όταν λέμε αποφύγαμε τα χειρότερα..</h2></div>		
	<div class="container card-wrapper">
		<?php foreach ($posts as $post):?>	
			<div class="card">
				<a href="<?=site_url('post/'.$post['id'])?>" class="pic lazy" data-src="<?=upload_images().$post['photo']?>">&nbsp;</a>
				<div class="title">
					<a href="<?=site_url('post/'.$post['id'])?>"><?=$post['title']?></a>
				</div>
				<div class="subtitle"><?=$post['subtitle']?></div>
			</div>
		<?php endforeach;?>
	</div>
</section>