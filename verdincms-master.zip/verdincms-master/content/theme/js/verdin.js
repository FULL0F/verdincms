$( document ).ready(function() {
    // Start Lazy
    $('.lazy').lazy();

    // Share Popup
    $('a.share-it').click(function(e) {
        e.preventDefault();
        PopupCenter($(this).attr('href'),'Share','900','500');  
        return false;
    });
	
    /* Fix Post Body Link Targets */
    $('.post-body a').attr('target', function() {
        if(this.host == location.host) return '_self'
        else return '_blank'
    });

    /* Navbar Scroll Color */
    $(window).scroll(function () {
        if ($(this).scrollTop() > 70) {
            $('.navbar').css("background-color", "rgba(255,255,255,0.9)");
        } else {
            $('.navbar').css("background-color", "#fff");
        }
    });

    /* Login Panel Toggle */
    $('.toggle-login').click(function(e) {
        e.preventDefault();
        $(".drop-login").toggle("slide", { direction: "up" }, 250);
        $(this).toggleClass("active");
    });

    /* Navigation Sidebar Toggle */
    $('.side-toggle').click(function(e) {
        $(".overlay").fadeToggle(250);
        $(".nav-sidebar").toggle("slide");
        $(this).find('i').toggleClass('icon-bars icon-cancel');
        $(this).find('i').toggleClass('animate-ham');
    });

    $('.overlay').click(function(e) {
        $(this).fadeToggle(250);
        $(".nav-sidebar").toggle("slide");
        $('.side-toggle').find('i').toggleClass('icon-bars icon-cancel');
        $('.side-toggle').find('i').toggleClass('animate-ham');
    });
 
    /* Toggle Panels Component */
    $('.toggle-collapse').click(function(e) {
        e.preventDefault();
        var href = $(this).attr('href'); 
        $(href).toggleClass("collapse");        
        $(this).toggleClass("rotate");
    });

}); // END document.ready

function PopupCenter(url, title, w, h) {
    // Fixes dual-screen position                         Most browsers      Firefox
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : screen.left;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : screen.top;
    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;
    var left = ((width / 2) - (w / 2)) + dualScreenLeft;
    var top = ((height / 2) - (h / 2)) + dualScreenTop;
    var newWindow = window.open(url, title, 'scrollbars=yes, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
    if (window.focus) {newWindow.focus();}
} //PopupCenter