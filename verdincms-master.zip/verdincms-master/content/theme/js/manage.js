$( document ).ready(function() {

if ($(".input-post-pic").val()!="newpost.jpg" && $(".input-post-pic").val()!="archive.jpg"){$(".rotate-photo").removeClass("hidden");}

if($("#maintextarea").length) {	
	    ClassicEditor
        .create( document.querySelector( '#maintextarea' ), {
        	mediaEmbed: {previewsInData:true}
        } )
	   .then( editor => {
	        theEditor = editor; // Save for later use.
	    } )       
        .catch( error => {
            console.error( error );
        } );
}

if($("#pagetextarea").length) {	
	    ClassicEditor
        .create( document.querySelector( '#pagetextarea' ), {
        	mediaEmbed: {previewsInData:true}
        } )
	   .then( editor => {
	        thePageEditor = editor; // Save for later use.
	    } )       
        .catch( error => {
            console.error( error );
        } );
}

$("input[name=userfile]").change(function() {
	if($(this).val()=="") {return;}
	$("#form-upload-pic").submit();
	$(".rotate-photo").removeClass("hidden");
});

$("input[name=insertfile]").change(function() {
	if($(this).val()=="") {return;}
	$("#form-insert-pic").submit();
});

$("input[name=insertfilepage]").change(function() {
	if($(this).val()=="") {return;}
	$("#form-insert-pic-page").submit();
});

/* Upload Photo Ajax*/
$('#form-upload-pic').on('submit', function(e){	
	e.preventDefault();	
	var action_path = $(this).attr("action");
	$(".progress-bar").css('opacity', '0.9');

	$.ajax({
		 url: action_path, method:"POST", data:new FormData(this),
		 contentType: false, cache: false, processData:false,
		 success:function(data) {
		 	var res = JSON.parse(data);
		 	$(".post-pic").css("background-image", "url('../content/images/" + res + "')");
		 	$(".input-post-pic").val(res);
		 },
		error: function(request, status, error) {alert(request.responseText);},
		xhr: function() {
			var xhr = new XMLHttpRequest();
			xhr.upload.addEventListener("progress", function(event) {
				if (event.lengthComputable) {
					var percentComplete = Math.round( (event.loaded / event.total) * 100 );		
					$(".progress").css({width: percentComplete + "%"});
				};
			}, false);
			return xhr;
		},
		complete: function(data) {
		 	$(".progress-bar").css('opacity', '0');
		}

	});  // END Ajax
}); //.form-upload-pic

/* Insert Photo to Post Ajax*/
$('#form-insert-pic').on('submit', function(e){	
	e.preventDefault();	
	var action_path = $(this).attr("action");
	var basepath = $(this).data("basepath");
	$.ajax({
		 url: action_path, method:"POST", data:new FormData(this),
		 contentType: false, cache: false, processData:false,
		 success:function(data) {
		 	var res = JSON.parse(data);
		 	filepath = basepath + "content/images/" + res;
			theEditor.model.change(writer => {      
			    const image = writer.createElement( 'image', { src: filepath } );
			    const insertPosition = theEditor.model.document.selection.getFirstPosition();
			    writer.append(image, insertPosition );
			});
		 },
		error: function(request, status, error) {alert(request.responseText);}
	});  // END Ajax
}); //.form-upload-pic

/* Insert Photo to Page Ajax*/
$('#form-insert-pic-page').on('submit', function(e){	
	e.preventDefault();	
	var action_path = $(this).attr("action");
	var basepath 	= $(this).data("basepath");
	$.ajax({
		 url: action_path, method:"POST", data:new FormData(this),
		 contentType: false, cache: false, processData:false,
		 success:function(data) {
		 	var res = JSON.parse(data);
		 	filepath = basepath + "content/images/" + res;
			thePageEditor.model.change(writer => {      
			    const image = writer.createElement( 'image', { src: filepath } );
			    const insertPosition = thePageEditor.model.document.selection.getFirstPosition();
			    writer.append(image, insertPosition );
			});
		 },
		error: function(request, status, error) {alert(request.responseText);}
	});  // END Ajax
}); //.form-upload-pic

/* Rotate Photo */
$( ".rotate-photo" ).click(function() {
	var filename = $(".input-post-pic").val();
	if(filename == ""){return;};
	var action_path = $(this).attr("action");

	$.ajax({
	    type:'POST', url: action_path, data: {filename:filename}, dataType: 'json', context: this,
	    success:function(response){
			$(".post-pic").css("background-image", "url('../content/images/" + response + "')");
	    },
	    error: function(xhr, status, error) {alert(xhr.responseText);}
	}); //END Ajax

}); // END .jq-rotate-photo

$(".set-archive").click(function() {
	$(".input-post-pic").val("archive.jpg");
	var imageUrl = $(this).data("base") + "archive.jpg";
	$(".post-pic").css('background-image', 'url(' + imageUrl + ')');
	$(".rotate-photo").addClass("hidden");
});

/* Edit */
$(".edit-save").click(function() {
	SavePost();
});

$(".edit-save-page").click(function() {
	SavePage();
});

$(".edit-recycle").click(function() {
	$(".input-post-status").val(3);
	SavePost();
});

$(".edit-recycle-page").click(function() {
	$(".input-page-status").val(3);
	SavePage();
});

$(".edit-unpublish").click(function() {
	$(".input-post-status").val(2);
	SavePost();
});

$(".edit-unpublish-page").click(function() {
	$(".input-page-status").val(2);
	SavePage();
});

$(".edit-publish").click(function() {
	$(".input-post-status").val(1);
	SavePost();
});

$(".edit-publish-page").click(function() {
	$(".input-page-status").val(1);
	SavePage();
});

$(".edit-preview").click(function() {
	$(this).find('i').toggleClass("icon-eye icon-edit");
	$(".photo-toolbox").toggle();
	$(".corner-ribbon").toggle();	
	$(".ck-toolbar").toggle();
	$(".btn-help").toggle();
});

$(".edit-preview-page").click(function() {
	$(this).find('i').toggleClass("icon-eye icon-edit");
	$(".photo-toolbox").toggle();
	$(".corner-ribbon").toggle();
	$(".ck-toolbar").toggle();
	$(".edit-page-fields").toggle();
	$(".btn-help").toggle();
});

$(".edit-shrink").click(function() {
	$(this).find('i').toggleClass("icon-arrow-down icon-arrow-up");
	$("article.post").slideToggle();
}); // .edit-shrink

$(".edit-shrink-page").click(function() {
	$(this).find('i').toggleClass("icon-arrow-down icon-arrow-up");
	$(".edit-page-header").slideToggle();
}); // .edit-shrink

/* Datetime Picker */
$(".show-date").click(function() {
	$(".date-switch").slideToggle();
}); // .show-date

$(".input-post-created").on("change", function() {
	var dt = moment($(".input-post-created").val(), "YYYY-MM-DD HH:mm:ss" ).toDate();
	moment.locale('el');
	var human = moment(dt).format('dddd DD MMMM YYYY');
	var human_long = moment(dt).format('dddd DD MMMM YYYY, h:mm:ss a');
	$(".date-display").text(human_long);
	$(".thedate").text(human);

}).trigger("change");

$(".b-datepicker").click(function() {
	var action = $(this).data("action");
	var dt = moment($(".input-post-created").val(), "YYYY-MM-DD HH:mm:ss" ).toDate();
	switch(action) {
		case "sec-plus":
			dt.setSeconds(dt.getSeconds() + 1);
			break;
		case "min-plus":
			dt.setMinutes(dt.getMinutes() + 1);
			break;
		case "hour-plus":
			dt.setHours(dt.getHours() + 1);
			break;
		case "day-plus":
			dt.setDate(dt.getDate() + 1);
			break;
		case "month-plus":
			dt.setMonth(dt.getMonth() + 1);
			break;
		case "year-plus":
			dt.setFullYear(dt.getFullYear() + 1);
			break;
		case "sec-minus":
			dt.setSeconds(dt.getSeconds() - 1);		
			break;	
		case "min-minus":
			dt.setMinutes(dt.getMinutes() - 1);
			break;
		case "hour-minus":
			dt.setHours(dt.getHours() - 1);
			break;
		case "day-minus":
			dt.setDate(dt.getDate() - 1);
			break;
		case "month-minus":
			dt.setMonth(dt.getMonth() - 1);
			break;
		case "year-minus":
			dt.setFullYear(dt.getFullYear() - 1);
			break;
		case "set-now":
			dt = new Date();
			break;				
		default:
			dt = new Date();
	}

	$(".input-post-created").val(moment(dt).format('YYYY-MM-DD HH:mm:ss'));
	$(".input-post-created").trigger("change");
});

/* Sort Pages */
if ($("ul.sort-pages").length) {
	$("ul.sort-pages").sortable({
		update: function (event, ui) {
			$(this).children().each(function (index){
				if ( $(this).data('position') != (index+1) ) {
					$(this).data('position', (index+1)).addClass('updated');
				}
			});
			saveNewPositions();
		}
	});
} //length

$(".pl-item .title, .pl-item .date").click(function() {
	$(this).parent().parent().find(".pl-footer").slideToggle(200);
	$(this).parent().parent().toggleClass("mb-2");
});

// Chart
if ($('.chart').length) {
    var max_value  = $('.chart').data("max-value");
    var cur_cnt    = 0;
    var cur_height = 0;
    var colourArray = ["rgb(123, 59, 158)","rgb(230, 80, 193)","rgb(195, 20, 69)","rgb(23, 208, 191)","rgb(192, 161, 200)","rgb(25, 156, 95)","rgb(247, 16, 116)","rgb(93, 45, 148)","rgb(53, 64, 30)","rgb(113, 9, 232)"];

    $(".chart .bar").each(function(index) {
        cur_cnt = $(this).data("value");
        cur_height = Math.round((cur_cnt / max_value) * 300);
        $(this).css("background-color", colourArray[index]);
        $(this).animate({height: cur_height,}, 500 );
    });
}

}); /* END document.ready */

// Custom Functions
function saveNewPositions() {
	var action_path = $("ul.sort-pages").data("action");
	var positions = [];
	$('.updated').each(function () {
		positions.push([$(this).data('id'),$(this).data('position')]);
		$(this).removeClass('updated');
	});

	$.ajax({
	    type:'POST', url: action_path, data: {positions:positions}, dataType: 'text',
	    success:function(response){
			//alert("saved");
	    }
	});
}

function SavePost() {
	$(".input-post-title").val($(".edit-title").text());
	$(".input-post-subtitle").val($(".edit-subtitle").text());
	$("input[name='submit-post']").click();
}

function SavePage() {
	$("input[name='submit-page']").click();
}

function fixAspectRatio() {
  $("iframe").not(".cke_wysiwyg_frame").each(function() {
    $(this).css('height', $(this).width() * 9/16);
  });
}

// Extensions
$.fn.extend({
    toggleText: function(a, b){
        return this.text(this.text() == b ? a : b);
    }
});

function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}