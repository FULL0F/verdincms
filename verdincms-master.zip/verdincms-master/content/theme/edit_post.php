<section class="section-post">
	<div class="container-sm">

		<nav class="nav-edit">
			<button class="btn-nav edit-shrink tooltip" data-tooltip="Μάζεμα"><i class="fm icon-arrow-up fm-lg"></i></button>
			<button class="btn-nav edit-preview tooltip" data-tooltip="Προεπισκόπιση"><i class="fm icon-eye fm-lg"></i></button>

			<button class="btn-nav show-date tooltip" data-tooltip="Ημερομηνία"><i class="fm icon-clock fm-lg"></i></button>
			
			<form action="<?=site_url('site/ajax_upload/insertfile')?>" enctype="multipart/form-data" id="form-insert-pic" method="post" data-basepath="<?=base_url()?>">
				<label class="btn-nav btn-upload-photo tooltip" data-tooltip="Εισαγωγή Φωτογραφίας">
			    	<i class="fm icon-camera fm-lg"></i><input type="file" name="insertfile">
				</label>
			</form>
			<span class="spacer">&nbsp;</span>
			<?php if(!empty(set_value('status'))):?>
				
				<?php if(set_value('status')!=3):?>
					<button class="btn-nav edit-recycle tooltip right" data-tooltip="Ανακύκλωση"><i class="fm icon-trash fm-lg"></i></button>
				<?php endif; ?>

				<?php if(set_value('status')!=2):?>
					<button class="btn-nav edit-unpublish tooltip right" data-tooltip="Πρόχειρο"><i class="fm icon-archive fm-lg"></i></button>
				<?php endif; ?>

				<?php if(set_value('status')!=1):?>
					<button class="btn-nav edit-publish tooltip right" data-tooltip="Δημοσίευση"><i class="fm icon-rocket fm-lg"></i></button>
				<?php endif; ?>

			<?php endif; ?>
			<button class="btn-nav edit-save tooltip right" data-tooltip="Αποθήκευση"><i class="fm icon-floppy fm-lg"></i></button>				
		</nav>

		<?=$datepicker?>

		<article class="post">
			<div class="post-title">
				<h1><div class="edit-title" contenteditable="true"><?=(!empty(set_value('title'))?set_value('title',$default='',$html_escape=FALSE):'Τίτλος')?></div></h1>
			</div>		
			<div class="post-pic lazy" data-src="<?=upload_images().(!empty(set_value('photo'))?set_value('photo'):'newpost.jpg')?>">
				<div class="photo-toolbox">
					<div class="progress-bar"><div class="progress"></div></div>					
					<a href="https://pixabay.com/" class="btn-nav-dk tooltip right" target="_blank" data-tooltip="Pixabay.com"><i class="fm icon-link"></i></a>
					<button class="btn-nav-dk set-archive tooltip right" data-base="<?=upload_images()?>" data-tooltip="Εικόνα αρχείου"><i class="fm icon-archive"></i></button>
					<button class="btn-nav-dk rotate-photo hidden tooltip right" action="<?=site_url('site/ajax_rotate_photo/left')?>" data-tooltip="Περιστροφή αριστερά"><i class="fm icon-left"></i></button>
					<button class="btn-nav-dk rotate-photo hidden tooltip right" action="<?=site_url('site/ajax_rotate_photo/right')?>" data-tooltip="Περιστροφή δεξιά"><i class="fm icon-right"></i></button>
					<form action="<?=site_url('site/ajax_upload/userfile')?>" enctype="multipart/form-data" id="form-upload-pic" method="post">
						<label class="btn-nav-dk btn-upload-photo tooltip right" data-tooltip="Προσθήκη εικόνας">
					    	<i class="fm icon-camera"></i><input type="file" name="userfile">
						</label>
					</form>					
				</div>				
			</div>		
			<div class="post-info noselect">
				<div><?=(!empty(set_value('hits'))?set_value('hits'):0)?> προβολές</div>
				<div class="thedate"><?=(!empty(set_value('created'))?date_gr(set_value('created')):date_now_gr())?> 
				</div>
			</div>
			<div class="post-subtitle">
				<h2><div class="edit-subtitle" contenteditable="true"><?=(!empty(set_value('subtitle'))?set_value('subtitle',$default='',$html_escape=FALSE):'Υπότιτλος')?></div></h2>
			</div>			
		</article>

		<form action="" method="post">
			<input type="hidden" class="input-post-created" name="created" value="<?=(!empty(set_value('created'))?set_value('created'):date('Y-m-d H:i:s'))?>">
			<input type="submit" name="submit-post" value="Save" class="hidden">
			<input type="hidden" class="input-post-status form-control" name="status" value="<?=(!empty(set_value('status'))?set_value('status'):2)?>">
			<input type="hidden" class="input-post-pic form-control" name="photo" value="<?=(!empty(set_value('photo'))?set_value('photo'):'newpost.jpg')?>">
			<input type="hidden" class="input-post-title form-control" name="title" value="<?=set_value('title')?>">
			<input type="hidden" class="input-post-subtitle form-control" name="subtitle" value="<?=set_value('subtitle')?>">
			<input type="hidden" name="id" value="<?=(!empty(set_value('id'))?set_value('id'):-1)?>">			
			<textarea id="maintextarea" name="post_body" class="form-control">
				 <?=set_value('post_body')?>
			</textarea>
		</form>

	</div>
	<div class="container-sm text-right mt-half">
		<button class="btn btn-sm btn-white btn-help tooltip right large" data-tooltip="Πάτα ENTER ή SHIFT+ENTER για να εισάγεις μια νέα γραμμή μετά ή πρίν από εικόνα/βίντεο (αφού το επιλέξεις)"><?=count_words(set_value('post_body'))?> λέξεις <i class="fm icon-info"></i></button>		
	</div>
</section>

<!-- Status Indicators -->
<?php if(!empty(set_value('status'))):?>
	<?php if(set_value('status')==3):?>
		<div class="corner-ribbon bottom-right sticky red shadow">Διεγραμμένο</div>
	<?php endif;?>
	<?php if(set_value('status')==2):?>
		<div class="corner-ribbon bottom-right sticky orange shadow">Πρόχειρο</div>
	<?php endif;?>
<?php else:?>
	<div class="corner-ribbon bottom-right sticky green shadow">Νέο άρθρο</div>
<?php endif;?>