<section class="section-post">
	<div class="container-sm">
		<article class="post">
			<div class="post-title">
				<h1><?=$title?></h1>
			</div>
			<div class="post-pic lazy" data-src="<?=upload_images().$photo?>">
				&nbsp;
			</div>		
			<div class="post-info">
				<div><?=$hits?> προβολές</div>
				<div><?=date_gr($created)?></div>
			</div>
			<div class="post-subtitle">
				<h2><?=$subtitle?></h2>
			</div>
			<div class="post-body"><?=$body?></div>
			<div class="spread-this">
				<h4>Μοιράσου το άρθρο με τους φίλους σου.</h4>
				<p>Με τον τρόπο αυτό στηρίζεις τις τελευταίες οάσεις ελεύθερης δημόσιας γραφής. Στήριξε τη σελίδα για να μπορεί αργότερα να στηρίξει και σένα.</p>
				<div class="spread-this-icons">
					<a href="whatsapp://send?text=<?=urlencode(current_url())?>"><i class="fm icon-whatsapp"></i></a>
					<a class="share-it" href="https://www.facebook.com/sharer/sharer.php?u=<?=urlencode(current_url())?>"><i class="fm icon-facebook"></i></a>
					<a class="share-it" href="http://twitter.com/share?text=<?=$title?>&url=<?=urlencode(current_url())?>"><i class="fm icon-twitter"></i></a>
					<a class="share-it" href="http://www.reddit.com/submit?url=<?=urlencode(current_url())?>&title=<?=$title?>"><i class="fm icon-reddit"></i></a>
					<a href="mailto:?subject=<?=$title?>&body=<?=$title.'%0D%0A%0D%0A'.$subtitle.'%0D%0A%0D%0A'.urlencode(current_url())?>"><i class="fm icon-email"></i></a>
				</div>
			</div>
		</article>
	</div>
</section>

<section class="section-posts">
	<div class="container"><h2 class="text-center">Ρίξε μια ματιά και στα τελευταία μου άρθρα..</h2></div>
	<div class="container card-wrapper">
		<?php foreach ($moreposts as $post):?>	
			<div class="card">
				<a href="<?=site_url('post/'.$post['id'])?>" class="pic lazy" data-src="<?=upload_images().$post['photo']?>">&nbsp;</a>
				<div class="title">
					<a href="<?=site_url('post/'.$post['id'])?>"><?=$post['title']?></a>
				</div>
				<div class="subtitle"><?=$post['subtitle']?></div>
			</div>
		<?php endforeach;?>
	</div>
</section>