<section class="section-stats">
<div class="container-sm">
	<div class="page">
		<div class="stats-display">
			<div><?=$stats['users_online']['cnt']?></div>
			<div><?=$stats['daily_visitors'][0]['cnt']?></div>			
		</div>
		<h1>Στατιστικά</h1>
		<ul class="stats">
			<li class="imp">
				<span>Επισκέπτες αυτή τη στιγμή</span>
				<span><?=$stats['users_online']['cnt']?></span>
			</li>
			<li>
				<span>Σύνολο άρθρων</span>
				<span><?=$stats['total_posts']?></span>
			</li>
			<li>
				<span>Σύνολο σελίδων</span>
				<span><?=$stats['total_pages']?></span>
			</li>			
			<li>
				<span>Μέση τιμή αριθμού επισκεπτών ημερησίως</span>
				<span><?=$stats['avg_visitors_day']?></span>
			</li>
			<li>
				<span>Μέση τιμή αριθμού επισκεπτών μηνιαίως</span>
				<span><?=$stats['avg_visitors_month']?></span>
			</li>
			<li>
				<span>Μέση τιμή αριθμού επισκεπτών ετησίως</span>
				<span><?=$stats['avg_visitors_year']?></span>
			</li>
			<li>
				<span>Ρυθμός Ανάπτυξης (Μήνα)</span>
				<span class="<?=($stats['growth']>0?'positive':'negative')?>"><?=$stats['growth']?>%</span>
			</li>	
			<li>
				<span>Συσκευές iOS</span>
				<span><?=$stats['ios_devices']['cnt']?>%</span>
			</li>
			<li>
				<span>Σύνολο αρχείων</span>
				<span><?=$stats['cron'][0]['value']?></span>
			</li>
			<li>
				<span>Τελευταία εκτέλεση Cron</span>
				<span><?=datetime_gr($stats['cron'][1]['value'])?></span>
			</li>
			<li>
				<span>Η σελίδα υπολογίστηκε σε</span>
				<span>{elapsed_time} sec</span>
			</li>
		</ul>

		<h2>Χώρες</h2>
		
		<div class="chart" data-max-value="<?=max(array_column($stats['countries'],'cnt'))?>">
			<?php foreach ( array_slice($stats['countries'],0,10) as $item):?>	
				<div class="bar-wrap">
					<div class="bar" data-value="<?=$item['cnt']?>">&nbsp;</div>
					<div class="bar-label"><?=$item['country']?></div>
					<div class="bar-flag"><img src="<?=theme_images().'flags/'.strtolower($item['country_code']).'.svg'?>"></div>
				</div>
			<?php endforeach;?>
		</div>
		
		<ul class="stats countries">
		<?php foreach ($stats['countries'] as $item):?>
			<li>
				<span class="flag"><img src="<?=theme_images().'flags/'.strtolower($item['country_code']).'.svg'?>"></span> 
				<span class="country"><?=$item['country']?></span>
				<span><?=$item['cnt']?></span>
				<span><?=$item['perc']?>%</span>
			</li>
		<?php endforeach;?>
		</ul>		

		<h2>Επισκέπτες</h2>
		<ul class="stats">
		<?php foreach ($stats['daily_visitors'] as $item):?>
			<li>
				<span><?=$item['thedate']?></span>
				<span><?=$item['cnt']?></span>
			</li>
		<?php endforeach;?>			
		</ul>

		<h2><a href="#hits" class="toggle-collapse">Προβολές</a></h2>
		<ul class="stats collapse" id="hits">
		<?php foreach ($stats['daily_hits'] as $item):?>
			<li>
				<span><?=$item['thedate']?></span>
				<span><?=$item['cnt']?></span>
			</li>
		<?php endforeach;?>
		</ul>

		<h2><a href="#pop_posts" class="toggle-collapse">Δημοφιλή Άρθρα</a></h2>
		<ul class="stats collapse" id="pop_posts">
		<?php foreach ($stats['popular_posts'] as $item):?>
			<li>
				<span class="stats-pop-title"><a href="<?=site_url('post/'.$item['id'])?>"><?=$item['title']?></a></span>
				<span><?=$item['hits']?></span>
			</li>
		<?php endforeach;?>
		</ul>

		<h2><a href="#pop_pages" class="toggle-collapse">Δημοφιλείς Σελίδες</a></h2>
		<ul class="stats collapse" id="pop_pages">
		<?php foreach ($stats['popular_pages'] as $item):?>
			<li>
				<span class="stats-pop-title"><a href="<?=site_url($item['slug'])?>"><?=$item['title']?></a></span>
				<span><?=$item['hits']?></span>
			</li>
		<?php endforeach;?>
		</ul>		

		<h2><a href="#hourly" class="toggle-collapse">Ωριαία επισκεψιμότητα</a></h2>
		<ul class="stats hourlies collapse" id="hourly">
		<?php foreach ($stats['hourly_visitors'] as $item):?>
			<li>
				<span><?=$item['thehour']?>:00</span>
				<span>(<?=$item['cnt']?>)</span>		
				<span><?=$item['perc']?>%</span>
			</li>
		<?php endforeach;?>			
		</ul>

	</div>
</div>	
</section>