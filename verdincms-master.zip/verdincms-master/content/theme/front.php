<section class="section-quote">
	<div class="container quote"><?=lang('slogan')?></div>
</section>
<section class="section-posts">
	<div class="container card-wrapper">
		<?php foreach ($posts as $post):?>	
			<div class="card">
				<a href="<?=site_url('post/'.$post['id'])?>" class="pic lazy" data-src="<?=upload_images().$post['photo']?>">&nbsp;</a>
				<div class="title">
					<a href="<?=site_url('post/'.$post['id'])?>"><?=$post['title']?></a>
				</div>
				<div class="subtitle"><?=$post['subtitle']?></div>
			</div>
		<?php endforeach;?>
	</div>
</section>