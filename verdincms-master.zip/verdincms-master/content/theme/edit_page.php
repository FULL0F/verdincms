<section class="section-page">
<div class="container-sm">

		<nav class="nav-edit">
			<button class="btn-nav edit-shrink-page tooltip" data-action="" data-tooltip="Μάζεμα"><i class="fm icon-arrow-up fm-lg"></i></button>
			<button class="btn-nav edit-preview-page tooltip" data-tooltip="Προεπισκόπιση"><i class="fm icon-eye fm-lg"></i></button>
			
			<form action="<?=site_url('site/ajax_upload/insertfilepage')?>" enctype="multipart/form-data" id="form-insert-pic-page" method="post" data-basepath="<?=base_url()?>">
				<label class="btn-nav btn-upload-photo tooltip" data-tooltip="Εισαγωγή Φωτογραφίας">
			    	<i class="fm icon-camera fm-lg"></i><input type="file" name="insertfilepage">
				</label>
			</form>
			<span class="spacer">&nbsp;</span>
			<?php if(!empty(set_value('status'))):?>
				
				<?php if(set_value('status')!=3):?>
					<button class="btn-nav edit-recycle-page tooltip right" data-tooltip="Ανακύκλωση"><i class="fm icon-trash fm-lg"></i></button>
				<?php endif; ?>

				<?php if(set_value('status')!=2):?>
					<button class="btn-nav edit-unpublish-page tooltip right" data-tooltip="Πρόχειρο"><i class="fm icon-archive fm-lg"></i></button>
				<?php endif; ?>

				<?php if(set_value('status')!=1):?>
					<button class="btn-nav edit-publish-page tooltip right" data-tooltip="Δημοσίευση"><i class="fm icon-rocket fm-lg"></i></button>
				<?php endif; ?>

			<?php endif; ?>
			<button class="btn-nav edit-save-page tooltip right" data-tooltip="Αποθήκευση"><i class="fm icon-floppy fm-lg"></i></button>				
		</nav>

	<div class="page">		
		<form action="" method="post">
			<input type="submit" name="submit-page" value="Save" class="hidden">
			<input type="hidden" class="input-page-status form-control" name="status" value="<?=(!empty(set_value('status'))?set_value('status'):1)?>">
			<input type="hidden" name="id" value="">
			<div class="edit-page-header">
				<img class="page-photo" src="<?=theme_images().'svg/'.(!empty(set_value('photo'))?set_value('photo'):'newpage.svg')?>">
				<div class="edit-page-fields">
					<div class="input-group">
						<input type="text" class="input-page-title form-control" placeholder="Τίτλος" name="title" value="<?=set_value('title')?>">
						<label>Τίτλος</label>						
					</div>
					
					<div class="input-group">
						<input type="text" class="input-page-slug form-control" placeholder="Σύνδεσμος" name="slug" value="<?=set_value('slug')?>">
						<label>Σύνδεσμος</label>						
					</div>

					<div class="input-group">
						<input type="text" class="input-page-pic form-control" name="photo" placeholder="Εικόνα" value="<?=set_value('photo')?>">
						<label>Εικόνα</label>						
					</div>						
				</div>				
			</div>
					
			<textarea id="pagetextarea" name="page_body" class="form-control">
				 <?=set_value('page_body')?>
			</textarea>
		</form>

	</div>
</div>

	<div class="container-sm text-right mt-1">
		<button class="btn btn-sm btn-white btn-help tooltip right large" data-tooltip="Πάτα ENTER ή SHIFT+ENTER για να εισάγεις μια νέα γραμμή μετά ή πρίν από εικόνα/βίντεο (αφού το επιλέξεις)"><?=count_words(set_value('page_body'))?> λέξεις <i class="fm icon-info"></i></button>	
	</div>
</section>

<!-- Status Indicators -->
<?php if(!empty(set_value('status'))):?>
	<?php if(set_value('status')==3):?>
		<div class="corner-ribbon bottom-right sticky red shadow">Διεγραμμένο</div>
	<?php endif;?>
	<?php if(set_value('status')==2):?>
		<div class="corner-ribbon bottom-right sticky orange shadow">Πρόχειρο</div>
	<?php endif;?>
<?php else:?>
	<div class="corner-ribbon bottom-right sticky green shadow">Νέα σελίδα</div>
<?php endif;?>