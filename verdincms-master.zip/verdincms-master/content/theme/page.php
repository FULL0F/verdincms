<section class="section-page">
<div class="container-sm">
	<article class="page">
		<img class="page-photo" src="<?=theme_images().'svg/'.$photo?>">
		<div class="page-body"><?=$body?></div>
	</article>
</div>	
</section>
<?=$widget?>