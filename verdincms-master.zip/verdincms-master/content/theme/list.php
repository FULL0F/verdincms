<section class="section-allposts">
	<div class="container">
		<div class="pl-selector">
			<a href="<?=site_url('list/posts')?>" class="<?=($type=='posts'?'active':'')?>">Άρθρα</a>
			<a href="<?=site_url('list/pages')?>" class="<?=($type=='pages'?'active':'')?>">Σελίδες</a>
		</div>
		<div class="postlist">
			<?php foreach ($posts as $post):?>
				<div class="pl-wrapper">
					<div class="pl-item">

						<?php if($post['status']==3):?>
							<div class="indicator deleted">Διεγραμμένο</div>
						<?php endif;?>

						<?php if($post['status']==2):?>
							<div class="indicator draft">Πρόχειρο</div>
						<?php endif;?>

						<?php if( $post['status']==1 && strtotime($post['created']) >= strtotime($db_now) ):?>
							<div class="indicator future">Μελλοντικό</div>
						<?php endif;?>					

						<div class="title noselect"><?=$post['title']?></div>
						<div class="date noselect"><?=datetime_gr($post['created'])?></div>
						<a href="<?=site_url($type_edit.'/'.$post['id'])?>" class="btn noshadow"><i class="fm icon-edit"></i></a>
						<?php if($post['status']==1):?>
							<?php if($type=='posts'):?>
								<a href="<?=site_url('post/'.$post['id'])?>" class="btn noshadow"><i class="fm icon-eye"></i></a>	
							<?php elseif($type=='pages'):?>
								<a href="<?=site_url($post['slug'])?>" class="btn noshadow"><i class="fm icon-eye"></i></a>	
							<?php endif;?>					
						<?php endif;?>
					</div><!-- pl-item -->
					<div class="pl-footer">						
						<div class="subtitle"><?=$post['subtitle']?></div>
						<div class="pl-footer-info">
							<div class="id">id: <?=$post['id']?></div>
							<div class="hits">προβολές: <?=$post['hits']?></div>
							<?php if($type=='pages'):?>
								<div class="position">σειρά: <?=$post['position']?></div>
							<?php endif;?>
							<div class="photo">φωτό: <?=$post['photo']?></div>
							<div class="date-footer"><?=datetime_gr($post['created'])?></div>
						</div>
					</div><!-- pl-footer -->
				</div>

			<?php endforeach;?>
		</div>
	
	</div><!-- Container -->
	
	<div class="container text-center mt-2">
	<?php if(!is_null($offset)):?>	
		<a href="<?=site_url('list/'.$type.'/'.($offset+75))?>"><i class="fm icon-arrow-left-round fm-2x"></i></a>
	<?php else:?>
		<a href="<?=site_url('list/'.$type)?>"><i class="fm icon-home fm-2x"></i></a>
	<?php endif;?>
	</div>
	
</section>