<?php
  header('Content-Type: application/xml');
  echo '<?xml version="1.0" encoding="UTF-8"?' . ">\n";
?>
<rss version="2.0"
    xmlns:content="http://purl.org/rss/1.0/modules/content/"
    xmlns:wfw="http://wellformedweb.org/CommentAPI/"
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:atom="http://www.w3.org/2005/Atom"
    xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
    xmlns:slash="http://purl.org/rss/1.0/modules/slash/"
    >
 
    <channel>
        <title><?="$cfg_site_name RSS"?></title>
        <atom:link href="<?=site_url('feed')?>" rel="self" type="application/rss+xml" />
        <link><?=site_url('feed')?></link>
        <description><?=$cfg_site_description?></description>
        <lastBuildDate><?=date('r', time())?></lastBuildDate>
        <language><?=$cfg_site_language?></language>
        <sy:updatePeriod>hourly</sy:updatePeriod>
        <sy:updateFrequency>1</sy:updateFrequency>
        <generator><?=base_url().'?v=3.35'?></generator>
  
        <?php foreach($posts as $item): ?>
        <item>
            <title><?=xml_convert($item['title'])?></title>
            <link><?=site_url('post/'.$item['id'])?></link>
            <guid><?=site_url('post/' . $item['id'])?></guid>
            <description><![CDATA[<?=$item['subtitle']?>]]></description>
            <pubDate><?=date(DATE_RSS, strtotime($item['created']))?></pubDate>
            <category>Misc</category>            
        </item>

        <?php endforeach; ?>
     
    </channel>
</rss>