<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$db =& DB();
$db->select('setting, value');
$query = $db->get('config');
foreach ($query->result() as $row) {$config['cfg_'.$row->setting] = $row->value;}