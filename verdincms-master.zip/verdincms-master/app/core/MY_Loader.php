<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Loader extends CI_Loader {

	function __construct(){
		parent::__construct();
	}

   /* Display Function */
   public function display($view,$data=array(),$h_data=array(),$f_data=array()) {
        $CI       = & get_instance();
        $CI->load->view('inc/html_header', $h_data);
        $nav_data['pages']  = $CI->system_db->get_table('pages','title,slug','status=1','position');
        $CI->load->view('inc/nav', $nav_data);
        $CI->load->view($view, $data);
        $CI->load->view('inc/footer', $nav_data);
        $CI->load->view('inc/html_footer', $f_data);
    }

} //MY_Loader