<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Site extends CI_Controller {

	function __construct() {
        parent::__construct();        
        $this->load->model('mod_content');
        $this->load->model('mod_stats');
    }   	

/* Frontpage */
public function index() {
	$data['posts']       = $this->mod_content->getPosts(30);
	$this->load->display('front',$data);
	$this->mod_stats->trackVisitor();
}

/* Page */
public function page($slug) {
    $data = $this->mod_content->getPage($slug);
    $data['body'] = $this->mod_content->renderPage($data['body']);
    if ($slug=='top30') {$display_title=FALSE;} else {$display_title=TRUE;}
    if ($slug!='worst30') {$data['widget'] = $this->mod_content->block_top30($display_title);
    } else {$data['widget'] = $this->mod_content->block_worst30();}
    
    $id = $this->system_db->get_value('pages','id','slug="'.$slug.'"');
    $h_data['page_id'] = $id;
	$this->load->display('page',$data,$h_data);
    $this->mod_stats->countHit($id,'pages');
	$this->mod_stats->trackVisitor();
}

/* Post */
public function post($id) {
	if(!is_numeric($id)){redirect(base_url());} // Not a number
	$data = $this->mod_content->getPost($id);
	if(empty($data['id'])) {redirect(base_url());} // No Post Exists
    if($data['status']!=1) {redirect(base_url());} // Not Public
	$h_data['metas']    = $this->load->view('inc/og_metas',$data, TRUE);
	$data['moreposts']  = $this->mod_content->getOtherPosts($id,30);
	$this->load->display('post',$data,$h_data);
	$this->mod_stats->countHit($id,'posts');
	$this->mod_stats->trackVisitor($id);
}

/* 404 */
public function p404() {$this->page('p404');}

/* RSS Feed */
public function feed() {
    $this->load->helper('xml');
    $this->load->helper('text'); 
    $data['posts'] = $this->mod_content->getPosts(30);
    header("Content-Type: application/rss+xml; charset=UTF-8");    
    $this->load->view('rss', $data);
}

/* Stats */
public function stats() {
	if(!isLoggedIn()){redirect(base_url());}
    $data['stats'] = $this->mod_stats->getStats();
    $f_data['scripts'] = script_tag(theme_url().'js/manage.min.js');
	$this->load->display('stats',$data,NULL,$f_data);
}

/* Stats */
public function settings() {
    if(!isLoggedIn()){redirect(base_url());}    
    $data['files']         = $this->system_core->getfilesInFolder('./content/backups');
    $data['photos']        = $this->mod_content->getOrphanPhotos();
    $data['deleted_posts'] = $this->mod_content->getDeletedPosts();
    $data['deleted_pages'] = $this->mod_content->getDeletedPages();
    $data['php_info']      = $this->system_core->phpinfo_array();
    $data['pages']         = $this->mod_content->getPagesLight();
    $data['settings']      = $this->mod_content->getSettings();

    /* Basic Settings */
    // Not Submitted
    if( !$this->input->post('submitSettings') ) {
        foreach ($data['settings'] as $item) {$_POST[$item['setting']] = $item['value'];}
    }

    // Submitted
    if($this->input->post('submitSettings')){
        $insertArray = array();
        foreach ($data['settings'] as $item) {
            $insertArray[$item['setting']] = $this->input->post($item['setting']);
        }  
        $this->mod_content->update_settings($insertArray);
    } // END Submitted    

    // Backup Database
    if($this->input->post('backUpDb')){
        $this->system_core->BackupDB('./content/backups');
        $data['files'] = $this->system_core->getfilesInFolder('./content/backups');
    }
    
    // Delete Recycled Posts
    if($this->input->post('delRecycledPosts')){
       $this->mod_content->delRecycledPosts();
       $data['deleted_posts'] = $this->mod_content->getDeletedPosts();
       $data['photos'] = $this->mod_content->getOrphanPhotos();
    }

    // Delete Recycled Pages
    if($this->input->post('delRecycledPages')){
       $this->mod_content->delRecycledPages();
       $data['deleted_pages'] = $this->mod_content->getDeletedPages();
       $data['photos'] = $this->mod_content->getOrphanPhotos();
    }

    // Delete Photos
    if($this->input->post('delPhotos')){
       $this->mod_content->delUnusedPhotos();
       $data['photos'] = $this->mod_content->getOrphanPhotos();
    }

    $f_data['scripts']  = script_tag(theme_assets().'jquery/jquery-ui.min.js');
    $f_data['scripts'] .= script_tag(theme_url().'js/manage.min.js');
    $this->load->display('settings',$data,NULL,$f_data);
}

/* All Posts */
public function list($type,$offset=0) {
	if(!isLoggedIn()){redirect(base_url());}
    $data['db_now']    = $this->system_db->db_now();
    $data['type']      = $type;
    $data['type_edit'] = 'edit_'.substr($type, 0, -1);
    switch ($type) {
        case 'posts':
            $data['posts'] = $this->mod_content->getAllPosts($offset);
            $max_records   = $this->system_db->countRecords('posts');
            break;
        case 'pages':
            $data['posts'] = $this->mod_content->getAllPages($offset);
            $max_records   = $this->system_db->countRecords('pages');
            break;
        default:
            redirect(base_url());
            break;
    }

    if ($offset+75 >=$max_records) {$data['offset'] = NULL;} else {$data['offset'] = $offset;}
    $f_data['scripts'] = script_tag(theme_url().'js/manage.min.js');
	$this->load->display('list',$data,NULL,$f_data);
}

/* Ajax Upload Photo */
public function ajax_upload($userfile) {
    if(!isLoggedIn()){return;}
 // Upload
    $config['upload_path']          = './content/images/';
    $config['allowed_types']        = 'gif|jpg|png|jpeg';
    $config['max_size']             = 20000000;
    $config['max_width']            = 10000;
    $config['max_height']           = 10000;
    $config['file_name']            = date("U");
    $this->load->library('upload', $config);

if ( !$this->upload->do_upload($userfile) ) {
        $status = strip_tags($this->upload->display_errors());
    } else {
        $data['upload_data'] = $this->upload->data();        
        $filepath = $this->upload->data('full_path');
        $filename = $this->upload->data('file_name');        
        $this->load->library('image_lib');
        $config['image_library']        = 'gd2';
        $config['source_image']         = $filepath;
        $config['create_thumb']         = FALSE;
        $config['maintain_ratio']       = TRUE;
        $config['width']                = 900;
        $config['height']               = 900;
        $config['quality']              = 80;
        $config['new_image']            = './content/images/'.$filename;
        $config['thumb_marker']         = false;
        $this->image_lib->clear();
        $this->image_lib->initialize($config);
        $this->image_lib->resize();
        $status = $filename;
    }
    echo json_encode($status);
}

/* Ajax Rotate Photo */
public function ajax_rotate_photo($direction) {
    if(!isLoggedIn()){return;}
    $filename = $this->input->post('filename');
    $status   = $this->mod_content->rotate_photo($filename,$direction);
    echo json_encode($status);
}

/* Edit Post */
public function edit_post($id=NULL) {    
    if(!isLoggedIn()){redirect(base_url());}
    if(empty($id)) {redirect(base_url());}
    $data['datepicker'] = $this->load->view('inc/datepicker',NULL,TRUE);
  
    // Not Submitted
    if(!$this->input->post('submit-post') && $id!='new') { 
        $post = $this->mod_content->getPost($id);
        $_POST['id']        = $post['id'];
        $_POST['status']    = $post['status'];
        $_POST['photo']     = $post['photo'];
        $_POST['title']     = $post['title'];
        $_POST['subtitle']  = $post['subtitle'];
        $_POST['post_body'] = $post['body'];
        $_POST['created']   = $post['created'];
        $_POST['hits']      = $post['hits'];
    }

    // Submitted
    if($this->input->post('submit-post')){
        $insertData = array(
            'status'    => $this->input->post('status'),
            'photo'     => $this->input->post('photo'),
            'title'     => strip_tags($this->input->post('title')),
            'subtitle'  => strip_tags($this->input->post('subtitle')),
            'body'      => $this->input->post('post_body'),
            'created'   => $this->system_db->db_date($this->input->post('created'))
        );
        if($id=='new') {
            $new_id = $this->mod_content->insert_post($insertData);
            redirect('edit_post/'.$new_id);
        } else {$this->mod_content->update_post($insertData,$id);}
    } // END Submitted

    // Display
    $f_data['scripts']  = script_tag(assets_url().'ckeditor/ckeditor.js');
    $f_data['scripts'] .= script_tag(assets_url().'moment/moment.min.js');
    $f_data['scripts'] .= script_tag(theme_url().'js/manage.min.js');
    $this->load->display('edit_post',$data,NULL,$f_data);
}

/* Edit Page */
public function edit_page($id=NULL) {
    if(!isLoggedIn()){redirect(base_url());}
    if(empty($id)) {redirect(base_url());}
    $data['shrink_page'] = $this->session->userdata('shrink_page');

    // Not Submitted
    if(!$this->input->post('submit-page') && $id!='new') {
        $post = $this->mod_content->getPageId($id);
        $_POST['id']         = $post['id'];
        $_POST['status']     = $post['status'];
        $_POST['title']      = $post['title'];
        $_POST['slug']       = $post['slug'];
        $_POST['photo']      = $post['photo'];        
        $_POST['page_body']  = $post['body'];
    }

    // Submitted
    if($this->input->post('submit-page')){
        $insertData = array(
            'status'     => $this->input->post('status'),
            'title'      => strip_tags($this->input->post('title')),
            'slug'       => strip_tags($this->input->post('slug')),
            'photo'      => strip_tags($this->input->post('photo')),
            'body'       => $this->input->post('page_body')
        );
        if($id=='new') {
            $new_id = $this->mod_content->insert_page($insertData);
            redirect('edit_page/'.$new_id);
        } else {$this->mod_content->update_page($insertData,$id);}
    } // END Submitted    

    // Display
    $f_data['scripts']  = script_tag(theme_url().'assets/ckeditor/ckeditor.js');
    $f_data['scripts'] .= script_tag(theme_url().'js/manage.min.js');
    $this->load->display('edit_page',$data,NULL,$f_data);
}

/* Page Positions */
function ajax_positions() {
    $positions = $this->input->post('positions');
    foreach ($positions as $position ) {
        $id          = $position[0];
        $newPosition = $position[1];
            $this->db->set('position', $newPosition, FALSE);
            $this->db->where('id', $id);
            $this->db->update('pages');
    }
    echo "Success";
}

/* Cron Job */
function cron() {
    // wget -O - https://tomsnews.net/cron >/dev/null 2>&1
    if( $_SERVER['REMOTE_ADDR'] != $_SERVER['SERVER_ADDR'] ){redirect(base_url());}
    // Generate Sitemap
    $this->mod_content->createSitemap();
    // Backup Database
    $this->system_core->BackupDB('./content/backups');
    // Optimize Stats
    $this->mod_stats->optimizeStats();
    // Update Cron Table
    $this->mod_stats->updateCronTable();   
    echo "Success";
}

} // END Site