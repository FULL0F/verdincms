<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('isLoggedIn')) {
    function isLoggedIn() {
        $ci =& get_instance();
        return $ci->session->userdata('isUserLoggedIn');  
    }   
}

if ( ! function_exists('date_now')) {
    function date_now() {
        return date("Y-m-d H:i:s");
    } 
}

if ( ! function_exists('date_now_gr')) {
    function date_now_gr() {
    	$ci =& get_instance();
    	return $ci->system_core->formatToGreekDate(date_now());
    } 
}

if ( ! function_exists('date_gr')) {
    function date_gr($date) {
        $ci =& get_instance();
        return $ci->system_core->formatToGreekDate($date);
    } 
}

if ( ! function_exists('datetime_gr')) {
    function datetime_gr($date) {
        setlocale(LC_TIME, 'el_GR.UTF-8');
        $ci =& get_instance();
        return $ci->system_core->formatToGreekDatetime($date);
    } 
}

if ( ! function_exists('count_words')) {
    function count_words($str) {
        $ci =& get_instance();
        return $ci->system_core->count_words($str);
    } 
}
