<?php defined('BASEPATH') OR exit('No direct script access allowed');

/* 
	Verdin CMS Language File: Greek 
	https://verdincms.com
*/

$lang['slogan'] = 'Καλωσήρθες σε μια από τις τελευταίες οάσεις της ελεύθερης δημόσιας γραφής';