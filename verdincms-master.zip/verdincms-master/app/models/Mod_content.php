<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Mod_content extends CI_Model{

    function __construct() {
        $this->lang->load('verdin');
    }

function getPosts($limit) {
    $timezone_dif = $this->config->item('cfg_timezone_interval');
    $q_string  = "SELECT id,title,subtitle,photo,created FROM posts WHERE status=1 AND created <= (NOW() + INTERVAL $timezone_dif HOUR) ORDER BY created DESC LIMIT ".$limit;
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();
    return $result;
}

function getOtherPosts($id,$limit) {
    $timezone_dif = $this->config->item('cfg_timezone_interval');
    $q_string  = "SELECT * FROM posts WHERE status=1 AND created <= (NOW() + INTERVAL $timezone_dif HOUR) AND id<> ".$id." ORDER BY created DESC LIMIT ".$limit;
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();
    return $result;
}

function getTopPosts($limit,$reverse=FALSE) {
    if($reverse){$ord='ASC';} else {$ord='DESC';}
    $q = "SELECT *, hits / DATEDIFF(CURDATE(),created) AS ivalue FROM posts 
          WHERE status=1 AND created <= (NOW() - INTERVAL 1 DAY)
          ORDER BY ivalue $ord LIMIT $limit";
    $query  = $this->db->query($q);
    $result = $query->result_array();    
    return $result;
}

function getSoonPosts() {
    $q_string  = "SELECT * FROM posts WHERE status=2 AND created >= (NOW() - INTERVAL 30 DAY) ORDER BY created DESC";
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();    
    return $result;   
}

function getDeletedPosts() {    
    $q_string  = "SELECT * FROM posts WHERE status=3 ORDER BY created";
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();    
    return $result;
}

function getDeletedPages() {    
    $q_string  = "SELECT * FROM pages WHERE status=3 ORDER BY created";
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();    
    return $result;
}

function getAllPosts($offset) {
    $q_string  = "SELECT id,title,subtitle,photo,status,hits,created FROM posts ORDER BY created DESC LIMIT 75 OFFSET ".$offset;
    $query  = $this->db->query($q_string);
    $result = $query->result_array();    
    return $result;
}

function getAllPages($offset) {
    $q_string  = "SELECT * FROM pages ORDER BY created DESC LIMIT 75 OFFSET ".$offset;
    $query  = $this->db->query($q_string);
    $result = $query->result_array();
    foreach($result as &$item) {
        $item['subtitle'] = $this->system_core->shorten_string($item['body'],50);
    }
    return $result;
}

function getPagesLight() {
    $q_string  = "SELECT id,title,slug,position FROM pages WHERE status=1 ORDER BY position ASC";
    $query  = $this->db->query($q_string);
    $result = $query->result_array();    
    return $result;
}

function getPostsSitemap() {
    $q_string  = "SELECT id,created FROM posts WHERE status=1 AND created <= NOW() ORDER BY created DESC";
    $query  = $this->db->query($q_string);
    $result = $query->result_array();    
    return $result;
}

function getPagesSitemap() {
    $q_string  = "SELECT slug,created FROM pages WHERE status=1 ORDER BY created DESC";
    $query  = $this->db->query($q_string);
    $result = $query->result_array();    
    return $result;
}

function createSitemap() {
    $posts = $this->getPostsSitemap();
    $pages = $this->getPagesSitemap();
    $sitemap_file = fopen("sitemap.xml", "w") or die("Unable to open file!");
    
    $sm  = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
    $sm .='<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
    $sm .= "
    <url>
        <loc>https://tomsnews.net/</loc>
        <lastmod>".date('c')."</lastmod>
        <changefreq>daily</changefreq>
        <priority>1.00</priority>
    </url>"."\n";

    // Pages
    foreach ($pages as $page) {
        $sm .= "
    <url>
        <loc>".site_url($page['slug'])."</loc>
        <lastmod>".date('c', strtotime($page['created']))."</lastmod>
        <priority>0.90</priority>  
    </url>
        ";
    }

    // Posts
    foreach ($posts as $post) {
        $sm .= "
    <url>
        <loc>".site_url('post/'.$post['id'])."</loc>
        <lastmod>".date('c', strtotime($post['created']))."</lastmod>
        <priority>0.80</priority>  
    </url>
";
    }    

    $sm .= '</urlset>';
    fwrite($sitemap_file, $sm);
    fclose($sitemap_file);
}

function getPost($id) {    
    $q_string  = "SELECT * FROM posts WHERE id=".$id;
    $query  = $this->db->query($q_string);
    $result = $query->row_array();
    return $result;
}

function getPage($slug) {
    $q_string  = "SELECT * FROM pages WHERE slug='".$slug."' AND status IN (1,4)";
    $query     = $this->db->query($q_string);
    $result    = $query->row_array();
    $result['created'] = $this->system_core->formatToGreekDate($result['created']);
    return $result;
}

function getPageId($id) {
    $q_string  = "SELECT * FROM pages WHERE id=".$id;
    $query     = $this->db->query($q_string);
    $result    = $query->row_array();    
    return $result;
}

function getSettings() {
    $q_string  = "SELECT * FROM config ORDER BY position";
    $query     = $this->db->query($q_string);
    $result    = $query->result_array();
    return $result;
}

function updateTags($id,$body){
    $tags = $this->getTags($body);
	$this->db->set('tags', $tags, TRUE);
	$this->db->where('id', $id);
	$this->db->update('posts');
    return "done";
}

function GetQuitData($key) {
    $ptime = "2018-06-11";
    $timezone_server = $this->config->item('cfg_timezone_server');
    date_default_timezone_set($timezone_server);
    $etime = time() - strtotime($ptime);
    $etime = $etime/86400;
    $quitData = array(
        'atm1' => $this->system_core->number_format_thousands($etime,1),
        'atm2' => $this->system_core->number_format_thousands($etime/30,2),
        'atm3' => $this->system_core->number_format_thousands($etime*55),
        'atm4' => $this->system_core->number_format_thousands($etime*55/200,2),
        'atm5' => $this->system_core->number_format_thousands($etime*55*0.27027,2),
        'atm6' => $this->system_core->number_format_thousands($etime*55*0.0069444444444444,2),
        'atm7' => round($etime*55*0.27027/450,2)
    );    
    return $quitData[$key];
}

function rotate_photo($filename,$direction) {    
    $this->load->library('image_lib');
    $config['image_library']   = 'gd2';
    $config['quality']         = 80;
    if ($direction=='right') {
        $config['rotation_angle']  = '270';
    } elseif ($direction=='left') {
        $config['rotation_angle']  = '90';
    }
    $config['create_thumb']    = FALSE;
    $config['source_image']    = './content/images/'.$filename;
    $this->image_lib->clear();
    $this->image_lib->initialize($config);
    $this->image_lib->rotate();   
    return $filename . "?" .date('U');
}

function insert_post($insertData) {
    $this->db->insert("posts", $insertData);
    $insert_id = $this->db->insert_id();
    return $insert_id;
}

function update_post($insertData, $id) {
    $this->db->where('id', $id);
    $this->db->update('posts', $insertData);
    return "done";
}

function insert_page($insertData) {
    $this->db->insert("pages", $insertData);
    $insert_id = $this->db->insert_id();
    return $insert_id;
}

function update_page($insertData, $id) {
    $this->db->where('id', $id);
    $this->db->update('pages', $insertData);
    return "Success";
}

function getTags($str) {
    if(empty($str)) {return '';}
    $str     = $this->system_core->clear_string($str);    
    $tags    = $this->system_core->extractKeyWords($str);
    return $tags;   
}

function delRecycledPosts() {
    $this->db->where('status', '3');
    $this->db->delete('posts');
    return "Success";
}

function delRecycledPages() {
    $this->db->where('status', '3');
    $this->db->delete('pages');
    return "Success";
}

function delUnusedPhotos() {
    $unusedPics = $this->getOrphanPhotos();
    foreach ($unusedPics as $pic) { unlink('./content/images/' . $pic); }
    return "Success";
}

function getOrphanPhotos() {
    $allPics = $this->system_core->getfilesInFolder('./content/images');
    $allPics = array_diff($allPics, array('newpost.jpg','archive.jpg'));
    $featuredPics = $this->system_db->get_column_array('posts','photo');
    // Find Post Pics
    $alltexts = $this->system_db->get_column('posts','body');
    $postPics = array();
    foreach($alltexts as $text) {
        $postPics = array_merge($postPics,$this->system_core->findPicsInHTML($text['body']));
    }
    // Find Page Pics
    $alltexts = $this->system_db->get_column('pages','body');
    $pagePics = array();
    foreach($alltexts as $text) {
        $pagePics = array_merge($pagePics,$this->system_core->findPicsInHTML($text['body']));
    }
    $unusedPics = array_diff($allPics,$featuredPics);
    $unusedPics = array_diff($unusedPics,$postPics);
    $unusedPics = array_diff($unusedPics,$pagePics);
    return $unusedPics;
}

function setPostDateNow($id) {
    $this->db->set('created', 'NOW()', FALSE);
    $this->db->where('id', $id);
    $this->db->update('posts');
    return date_now_gr();    
}

/* Blocks */
function block_posts_soon() {
    $data['soon_posts']  = $this->getSoonPosts();
    $posts_soon = $this->load->view('inc/block_posts_soon',$data, TRUE);
    return $posts_soon;
}

function block_top30($display_title=TRUE) {
    $data['display_title'] = $display_title;
    $data['posts'] = $this->getTopPosts(30);
    $top_posts     = $this->load->view('inc/block_top30',$data, TRUE);
    return $top_posts;
}

function block_worst30() {
    $data['posts'] = $this->getTopPosts(30,TRUE);
    $worst_posts   = $this->load->view('inc/block_worst30',$data, TRUE);
    return $worst_posts;
}

function block_atmao() {
    $data['ids']  = $this->GetQuitData();
    $atmao = $this->load->view('inc/block_atmao',$data, TRUE);
    return $atmao;
}

/* Page Rendering */
function renderPage($body) {
    $pattern = '{{.*?}}';
    $rendered_body = mb_ereg_replace_callback($pattern,function($matches){
        return $this->getSmartTag($matches[0]);
    },$body);
    return $rendered_body;
}

function getSmartTag($tag) {
    $tag = str_replace(array('{{','}}'),'', $tag);
    switch ($tag) {
        case 'atm1':
            $data = $this->GetQuitData('atm1');
            break;
        case 'atm2':
            $data = $this->GetQuitData('atm2');
            break;
        case 'atm3':
            $data = $this->GetQuitData('atm3');
            break;
        case 'atm4':
            $data = $this->GetQuitData('atm4');
            break;
        case 'atm5':
            $data = $this->GetQuitData('atm5');
            break; 
        case 'atm6':
            $data = $this->GetQuitData('atm6');
            break; 
        case 'atm7':
            $data = $this->GetQuitData('atm7');
            break;
        case 'mig01':
            $data = $this->system_core->pastSince('2012-11-30 11:45:00');
            break;
        case 'mig02':
            $data = number_format($this->system_core->daysSince('2012-11-30 11:45:00')*80,0,',','.').'€';
            break;
        case 'mig03':
            $data = $this->system_core->pastSince('2015-07-10 17:00:00');
            break;                                                                                             
        default:
            $data = '';
            break;
    }    
    return $data;
}

function update_settings($insertArray) {
    foreach ($insertArray as $key => $value) {
        $this->db->set('value', $value);
        $this->db->where('setting', $key);
        $this->db->update('config');
    }
}

} // END Mod_content

